/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conditionalex;

import java.util.Scanner;

/**
 *
 * @author anshenoy
 */
public class WatchMovie {

    public static void main(String args[]) {
        Scanner sn = new Scanner(System.in);
        System.out.print("Ingrese el precio del boleto \n");
        int precio = sn.nextInt();
        System.out.println("Ingrese la clasificación de la pelicula en número del 1 al 5 ");
        int clasificacion = sn.nextInt();
        
        if(precio >= 12 && clasificacion == 5){
            System.out.println("Me interesa ver la pelicula");
        }
        else{
            System.out.println("No me interesa ver la pelicula");
        }
    }
}
